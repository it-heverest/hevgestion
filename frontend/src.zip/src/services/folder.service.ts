// services/folderService.ts
import axios from "axios";
import { API_CONFIG } from "../config/api";
import { authService } from "./auth.service"; // Import from auth.service, not AuthContext

export interface Folder {
  id: string;
  name: string;
  description?: string;
  status:
    | "DRAFT"
    | "PROCESSING_BALANCE"
    | "BALANCE_READY"
    | "DSF_GENERATED"
    | "DSF_VALIDATED"
    | "COMPLETED";
  fiscalYear: number;
  startDate: string;
  endDate: string;
  clientId: string;
  ownerId: string;
  isActive?: boolean;
  createdAt?: string;
  updatedAt?: string;
  client?: {
    id: string;
    name: string;
    country: string;
  };
  balances?: Array<{
    id: string;
    type: string;
    status: string;
  }>;
  dsf?: any;
}

export interface CreateFolderData {
  name: string;
  description?: string;
  clientId: string;
  fiscalYear: number;
  startDate: string;
  endDate: string;
}

export interface UpdateFolderData {
  name?: string;
  description?: string;
  status?: string;
}

/**
 * Folder Service
 *
 * Responsibilities:
 * - Handle all API communication for folders
 * - Use AuthService for token management
 * - Centralize error handling for folder operations
 */
class FolderService {
  private api = axios.create({
    baseURL: API_CONFIG.BASE_URL,
    timeout: 10000,
    withCredentials: true, // Required for HttpOnly cookies
    headers: {
      "Content-Type": "application/json",
    },
  });

  constructor() {
    this.setupInterceptors();
  }

  /**
   * Setup request and response interceptors
   */
  private setupInterceptors(): void {
    // Request interceptor to add auth token
    this.api.interceptors.request.use(
      (config) => {
        const token = authService.getToken();
        if (token) {
          config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
      },
      (error) => {
        return Promise.reject(error);
      }
    );

    // Response interceptor to handle global errors
    this.api.interceptors.response.use(
      (response) => response,
      (error) => {
        if (error.response?.status === 401) {
          // Token cleanup is handled by AuthService and AuthContext
          window.location.href = "/login";
        }
        return Promise.reject(error);
      }
    );
  }

  /**
   * Cancel all pending requests (placeholder for cleanup)
   */
  cancelAllRequests(): void {
    // Implementation would depend on your specific needs
    // This could use axios CancelToken if needed
  }

  // ==================== FOLDERS API ====================

  /**
   * Get all folders for a client
   */
  async getFolders(clientId: string): Promise<Folder[]> {
    try {
      const response = await this.api.get("/folders", {
        params: { clientId },
      });
      return response.data.folders;
    } catch (error) {
      console.error("Error fetching folders:", error);
      throw new Error("Erreur lors du chargement des dossiers");
    }
  }

  /**
   * Create a new folder
   */
  async createFolder(folderData: CreateFolderData): Promise<Folder> {
    try {
      console.log("Creating folder with data:", folderData);
      const response = await this.api.post("/folders", folderData);
      return response.data.folder;
    } catch (error: any) {
      console.error("Error creating folder:", error);
      console.error("Error response:", error.response?.data);

      if (error.response?.data?.message) {
        throw new Error(error.response.data.message);
      }

      throw new Error("Erreur lors de la création du dossier");
    }
  }

  /**
   * Close a folder
   */
  async closeFolder(folderId: string): Promise<Folder> {
    try {
      const response = await this.api.put(`/folders/${folderId}/close`);
      return response.data.folder;
    } catch (error: any) {
      console.error("Error closing folder:", error);

      if (error.response?.data?.message) {
        throw new Error(error.response.data.message);
      }

      throw new Error("Erreur lors de la clôture du dossier");
    }
  }

  /**
   * Get folders by client ID
   */
  async getFoldersByClient(clientId: string): Promise<Folder[]> {
    try {
      const response = await this.api.get("/folders", {
        params: { clientId },
      });
      return response.data.folders;
    } catch (error) {
      console.error("Error fetching folders by client:", error);
      throw new Error("Erreur lors du chargement des dossiers du client");
    }
  }

  /**
   * Get folder by ID
   */
  async getFolderById(folderId: string): Promise<Folder> {
    try {
      const response = await this.api.get(`/folders/${folderId}`);
      return response.data.folder;
    } catch (error) {
      console.error("Error fetching folder:", error);
      throw new Error("Erreur lors du chargement du dossier");
    }
  }

  /**
   * Get current active folder for a client
   */
  async getCurrentFolder(clientId: string): Promise<Folder | null> {
    try {
      const response = await this.api.get("/folders/current", {
        params: { clientId },
      });
      return response.data.folder;
    } catch (error) {
      console.error("Error fetching current folder:", error);
      throw new Error("Erreur lors du chargement du dossier actuel");
    }
  }

  /**
   * Update folder information
   */
  async updateFolder(
    folderId: string,
    folderData: UpdateFolderData
  ): Promise<Folder> {
    try {
      const response = await this.api.put(`/folders/${folderId}`, folderData);
      return response.data.folder;
    } catch (error: any) {
      console.error("Error updating folder:", error);

      if (error.response?.data?.message) {
        throw new Error(error.response.data.message);
      }

      throw new Error("Erreur lors de la modification du dossier");
    }
  }

  /**
   * Delete folder
   */
  async deleteFolder(folderId: string): Promise<void> {
    try {
      await this.api.delete(`/folders/${folderId}`);
    } catch (error) {
      console.error("Error deleting folder:", error);
      throw new Error("Erreur lors de la suppression du dossier");
    }
  }

  // ==================== ADDITIONAL FOLDER OPERATIONS ====================

  /**
   * Get folder with detailed information including balances and DSF
   */
  async getFolderWithDetails(folderId: string): Promise<Folder> {
    try {
      const response = await this.api.get(`/folders/${folderId}/details`);
      return response.data.folder;
    } catch (error) {
      console.error("Error fetching folder details:", error);
      throw new Error("Erreur lors du chargement des détails du dossier");
    }
  }

  /**
   * Duplicate folder for a new fiscal year
   */
  async duplicateFolder(
    folderId: string,
    newFiscalYear: number
  ): Promise<Folder> {
    try {
      const response = await this.api.post(`/folders/${folderId}/duplicate`, {
        fiscalYear: newFiscalYear,
      });
      return response.data.folder;
    } catch (error: any) {
      console.error("Error duplicating folder:", error);

      if (error.response?.data?.message) {
        throw new Error(error.response.data.message);
      }

      throw new Error("Erreur lors de la duplication du dossier");
    }
  }

  /**
   * Get folder statistics and progress
   */
  async getFolderProgress(folderId: string): Promise<any> {
    try {
      const response = await this.api.get(`/folders/${folderId}/progress`);
      return response.data;
    } catch (error) {
      console.error("Error fetching folder progress:", error);
      throw new Error("Erreur lors du chargement de la progression du dossier");
    }
  }

  /**
   * Update folder status
   */
  async updateFolderStatus(
    folderId: string,
    status: Folder["status"]
  ): Promise<Folder> {
    try {
      const response = await this.api.put(`/folders/${folderId}/close`, {
        status,
      });
      return response.data.folder;
    } catch (error: any) {
      console.error("Error updating folder status:", error);

      if (error.response?.data?.message) {
        throw new Error(error.response.data.message);
      }

      throw new Error("Erreur lors de la mise à jour du statut du dossier");
    }
  }

  /**
   * Get auth headers for external API calls if needed
   */
  getAuthHeaders(): Record<string, string> {
    return authService.getAuthHeaders();
  }
}

export const folderService = new FolderService();
